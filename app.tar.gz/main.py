import flet as ft


def main(page: ft.Page):
    page.padding = 0
    page.add(
        ft.Container(
            alignment=ft.alignment.center,
            expand=True,
            bgcolor="blue",
            content=ft.Text("B+ by Fet"),
        )
    )


ft.app(main)
